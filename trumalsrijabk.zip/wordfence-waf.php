<?php
// Before removing this file, please verify the PHP ini setting `auto_prepend_file` does not point to this.

if (file_exists('/home2/webmobi5/public_html/tirumalasrija/wp-content/plugins/wordfence/waf/bootstrap.php')) {
	define("WFWAF_LOG_PATH", '/home2/webmobi5/public_html/tirumalasrija/wp-content/wflogs/');
	include_once '/home2/webmobi5/public_html/tirumalasrija/wp-content/plugins/wordfence/waf/bootstrap.php';
}
?>