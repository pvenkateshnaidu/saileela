<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'webmobi5_316' );

/** MySQL database username */
define( 'DB_USER', 'webmobi5_316' );

/** MySQL database password */
define( 'DB_PASSWORD', '0F7A2DCEd6tq8uz9fi3r4ma1' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '%kCkb5cg]7zCE-itoKcX}Ew`%}CDQoajkTU/K,p#6D:qYtut|%dVIn7Ib?p(B<b ' );
define( 'SECURE_AUTH_KEY',  'X>zi>F+Sgiu*ha.4HABH> f9vL69TnW~kG7T_|%:98Q#UpM%$l~Qy+V7TpR%`TU&' );
define( 'LOGGED_IN_KEY',    '<?nrm`JtAi}(-/VE!5PNF5u+/:L3~&Dp3)LvVUNsg{5O{LcvjGbI)Ux~-fKTXooX' );
define( 'NONCE_KEY',        '#r`!`Dxo@iZ G%,4D)[C3H#c.(k?<J#{7P,SP~Y`[^P6QKgIi3<|jqyO0D!C&FBh' );
define( 'AUTH_SALT',        'Tz 3RaDg@Ks@&5eNm7v$f- FN[j1VHvI^X(Z:/7SO_kls;70I)`wkcr8k>QpU0O[' );
define( 'SECURE_AUTH_SALT', '`ZpbQTuDSdbI~]FMCPX:}>wxkX=K87Ci|%+g;Ny0B G#6 px)>iK:p0><6~bE9RD' );
define( 'LOGGED_IN_SALT',   '^%qn)c](yB^59,!n(8u`R7;~^X]PuK4ch4O.JCY5b4?<qxuH!mPOjHE;h5N9&GzK' );
define( 'NONCE_SALT',       '$IrrvJM8K>h^>=xx1GscGb~9k&TH*llb77mHY3ADxmSRXWz-H.6:1xIX`Ol>$e>}' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = '316_';



define( 'AUTOSAVE_INTERVAL',    300  );
define( 'WP_POST_REVISIONS',    5    );
define( 'EMPTY_TRASH_DAYS',     7    );
define( 'WP_AUTO_UPDATE_CORE',  true );
define( 'WP_CRON_LOCK_TIMEOUT', 120  );

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
